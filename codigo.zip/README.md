# flight-dynamics

NOTA: No use el valor de CD0 de roskam porque es una propuesta de modelo LINEAL.
Nosotros usamos un valor basado en un modelo NO LINEAL.

